import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<RegisteredUser> userList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1. Register a new user.");
            System.out.println("2. Login as an existing user.");
            System.out.println("3. Quit the program.");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            if (option == 1) {
                // Register a new user
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                while (!validateEmail(email)) {
                    System.out.print("Invalid email. Try again: ");
                    email = scanner.nextLine();
                }

                System.out.print("Enter password: ");
                String password = scanner.nextLine();
                while (!validatePassword(password)) {
                    System.out.print("Invalid password. Try again: ");
                    password = scanner.nextLine();
                }

                RegisteredUser newUser = new RegisteredUser(email, password);
                userList.add(newUser);
                System.out.println("User registered successfully!");
                System.out.println(newUser);

            } else if (option == 2) {
                // Login as an existing user
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter password: ");
                String password = scanner.nextLine();

                RegisteredUser loggedInUser = null;
                for (RegisteredUser user : userList) {
                    if (user.getEmail().equals(email) && user.getPassword().equals(password)) {
                        loggedInUser = user;
                        break;
                    }
                }

                if (loggedInUser != null) {
                    System.out.println("Login successful!");
                    userMenu(loggedInUser, userList);
                } else {
                    System.out.println("Login failed. Incorrect email or password.");
                }

            } else if (option == 3) {
                System.out.println("Exiting program.");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }

        scanner.close();
    }

    // User menu for logged-in users
    public static void userMenu(RegisteredUser user, ArrayList<RegisteredUser> userList) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("User Menu:");
            System.out.println("1. Print user details.");
            System.out.println("2. Change email address.");
            System.out.println("3. Change password.");
            System.out.println("4. Delete account.");
            System.out.println("5. Log out.");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            if (option == 1) {
                System.out.println(user);
            } else if (option == 2) {
                System.out.print("Enter new email: ");
                String newEmail = scanner.nextLine();
                while (!validateEmail(newEmail)) {
                    System.out.print("Invalid email. Try again: ");
                    newEmail = scanner.nextLine();
                }
                user.setEmail(newEmail);
                System.out.println("Email updated successfully!");
            } else if (option == 3) {
                System.out.print("Enter new password: ");
                String newPassword = scanner.nextLine();
                while (!validatePassword(newPassword)) {
                    System.out.print("Invalid password. Try again: ");
                    newPassword = scanner.nextLine();
                }
                user.setPassword(newPassword);
                System.out.println("Password updated successfully!");
            } else if (option == 4) {
                System.out.print("Are you sure you want to delete your account? (yes/no): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("yes")) {
                    userList.remove(user);
                    System.out.println("Account deleted successfully!");
                    break;
                }
            } else if (option == 5) {
                System.out.println("Logging out...");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Method to validate email
    public static boolean validateEmail(String email) {
        return email.contains("@") && email.indexOf('@') > 0 && email.indexOf('@') < email.length() - 1;
    }

    // Method to validate password
    public static boolean validatePassword(String password) {
        boolean hasUpperCase = false, hasLowerCase = false, hasDigit = false;

        if (password.length() >= 8) {
            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpperCase = true;
                if (Character.isLowerCase(c)) hasLowerCase = true;
                if (Character.isDigit(c)) hasDigit = true;
            }
        }

        return hasUpperCase && hasLowerCase && hasDigit;
    }
}
