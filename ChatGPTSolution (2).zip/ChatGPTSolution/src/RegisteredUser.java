public class RegisteredUser {
    // Fields
    private int userID;
    private String email;
    private String password;

    // Static variable to keep track of user ID increment
    private static int idCounter = 1;

    // Default constructor
    public RegisteredUser() {
        this.userID = idCounter++;
        this.email = "default@example.com";
        this.password = "Password123";
    }

    // Non-default constructor
    public RegisteredUser(String email, String password) {
        this.userID = idCounter++;
        this.email = email;
        this.password = password;
    }

    // Getter for userID (no setter because userID is immutable)
    public int getUserID() {
        return userID;
    }

    // Getter and Setter for email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // toString method to display user details
    @Override
    public String toString() {
        return "UserID: " + userID + ", Email: " + email + ", Password: " + password;
    }
}
