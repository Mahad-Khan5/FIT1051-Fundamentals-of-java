import java.util.ArrayList;
import java.util.List;

/**
 * Enum representing all available toppings.
 *
 * Each topping has:
 * a surcharge which is the extra cost
 * flags indicating whether it is allowed on pizza and/or pasta.
 *
 * Pizza toppings: HAM, CHEESE, MUSHROOMS, TOMATO, PINEAPPLE, SEAFOOD
 * Pasta toppings: BOLOGNESE, PRIMAVERA, MARINARA, TOMATO_SAUCE
 *
 * This enum is used to manage valid toppings and their pricing.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public enum Topping {

    HAM(2.00, true, false),
    CHEESE(2.00, true, false),
    MUSHROOMS(2.00, true, false),
    TOMATO(2.00, true, false),
    PINEAPPLE(2.50, true, false),
    SEAFOOD(3.50, true, false),
    BOLOGNESE(5.20, false, true),
    PRIMAVERA(5.20, false, true),
    MARINARA(6.80, false, true),
    TOMATO_SAUCE(4.00, false, true);

    /**
     * Additional cost added for this topping.
     */
    private final double surcharge;

    /**
     * True if this topping is valid on pizza.
     */
    private final boolean pizzaOk;

    /**
     * True if this topping is valid on pasta.
     */
    private final boolean pastaOk;

    /**
     * Constructs a Topping with the given surcharge and validity flags
     *
     * parameter (surcharge) is the additional cost for this topping
     * parameter (pizzaOk) is true if this topping may be used on pizza
     * parameter (pastaOk) is true if this topping may be used on pasta
     */
    Topping(double surcharge, boolean pizzaOk, boolean pastaOk) {
        this.surcharge = surcharge;
        this.pizzaOk = pizzaOk;
        this.pastaOk = pastaOk;
    }

    /**
     * Returns the extra amount for this topping
     */
    public double getSurcharge() {
        return surcharge;
    }

    /**
     * Returns true if this topping is valid on pasta, otherwise it retunrs false
     */
    public boolean isPastaTopping() {
        return pastaOk;
    }

    /**
     * Returns true if this topping is valid on pizza, otherwise it returns false
     */
    public boolean isPizzaTopping() {
        return pizzaOk;
    }

    /**
     * Returns an ArrayList of all toppings that are valid for pizza
     */
    public static List<Topping> getPizzaToppings() {
        List<Topping> result = new ArrayList<>();
        for (Topping t : Topping.values()) {
            if (t.isPizzaTopping()) {
                result.add(t);
            }
        }
        return result;
    }

    /**
     * Returns an ArrayList of all toppings that are valid for past
     */
    public static List<Topping> getPastaToppings() {
        List<Topping> result = new ArrayList<>();
        for (Topping t : Topping.values()) {
            if (t.isPastaTopping()) {
                result.add(t);
            }
        }
        return result;
    }
}
