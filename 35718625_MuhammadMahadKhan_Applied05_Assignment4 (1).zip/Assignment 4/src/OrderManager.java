import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Manages a queue of customer orders in first-in, first-out (FIFO) order.
 *
 * Provides methods to add new orders, cancel orders by ID, deliver orders
 * by various strategies (FIFO, highest price, meal-type priority), and list
 * or print pending orders.
 *
 * All operations occur in memory; no persistent storage is used.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class OrderManager {

    /**
     * The internal queue of pending orders.
     */
    private LinkedList<Order> pendingOrders;

    /**
     * Constructs a new OrderManager with an empty pending orders list.
     */
    public OrderManager() {
        pendingOrders = new LinkedList<>();
    }

    /**
     * Adds an order to the end of the queue.
     *
     * parameter (order) is the Order to add which is not null
     * throws IllegalArgumentException if order is null
     */

    public void addOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        pendingOrders.addLast(order);
    }

    /**
     * Cancels/removes an order matching the given order ID
     *
     * parameter (orderID) is the ID of the order to cancel which is not null
     * returns true if the order was found and removed otherwise returns false
     * throws IllegalArgumentException if orderID is null
     */

    public boolean cancelOrderByID(String orderID) {
        if (orderID == null || orderID.isBlank()) {
            throw new IllegalArgumentException("Order ID cannot be null or blank");
        }
        for (Order order : pendingOrders) {
            if (order.getOrderID().equals(orderID)) {
                pendingOrders.remove(order);
                return true;
            }
        }
        return false;
    }

    /**
     * Delivers (removes and returns) the next order in FIFO sequence.
     *
     * returns the next Order, or null if no orders are pending
     */
    public Order deliverNextOrderFIFO() {
        if (pendingOrders.isEmpty()) {
            return null;
        }
        return pendingOrders.removeFirst();
    }

    /**
     * Delivers (removes and returns) the order with the highest total cost.
     *
     * returns the highest cost Order, or null if no orders are pending
     */
    public Order deliverNextOrderByPrice() {
        if (pendingOrders.isEmpty()) {
            return null;
        }
        Order highest = null;
        for (Order order : pendingOrders) {
            if (highest == null || order.getTotalCost() > highest.getTotalCost()) {
                highest = order;
            }
        }
        pendingOrders.remove(highest);
        return highest;
    }

    /**
     * Delivers (removes and returns) the next order by meal type priority:
     * MEAT first, then VEGETARIAN, then VEGAN. If multiple orders share the
     * same meal type, the oldest among them is delivered first.
     *
     * returns the next prioritized Order, or null if none are pending
     */

    public Order deliverNextOrderByMealType() {
        if (pendingOrders.isEmpty()) {
            return null;
        }
        // First, find MEAT
        for (Order order : pendingOrders) {
            if (order.getMealType() == MealType.MEAT) {
                pendingOrders.remove(order);
                return order;
            }
        }
        // Next, find VEGETARIAN
        for (Order order : pendingOrders) {
            if (order.getMealType() == MealType.VEGETARIAN) {
                pendingOrders.remove(order);
                return order;
            }
        }
        // Otherwise, remove the first (VEGAN)
        return pendingOrders.removeFirst();
    }

    /**
     * returns a new ArrayList containing all pending Order objects
     */

    public List<Order> listPendingOrders() {
        List<Order> copy = new ArrayList<>();
        for (Order order : pendingOrders) {
            copy.add(order);
        }
        return copy;
    }

    /**
     * Prints all pending orders to the console. If none are pending,
     * prints a message indicating the queue is empty and there are no pending orders
     */
    public void printPendingOrders() {
        if (pendingOrders.isEmpty()) {
            System.out.println("No pending orders.");
        } else {
            for (Order order : pendingOrders) {
                System.out.println(order);
                System.out.println("-----");
            }
        }
    }
}
