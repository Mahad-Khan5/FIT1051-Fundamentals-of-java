import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

/**
 * Console application to manage take-away food orders.
 *
 * Uses Scanner, simple control structures, and ArrayLists.
 * All data is kept in memory; nothing is saved to disk.
 *
 * Functionality includes placing orders, delivering (FIFO), viewing
 * pending orders, canceling by ID, modifying before delivery, displaying
 * price lists, and viewing a sales summary.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class OrderApp {

    /**
     * Counter for delivered MEAT orders.
     */
    private static int meatCount = 0;

    /**
     * Counter for delivered VEGETARIAN orders.
     */
    private static int vegetarianCount = 0;

    /**
     * Counter for delivered VEGAN orders.
     */
    private static int veganCount = 0;

    /**
     * Total revenue from delivered orders in this run
     */
    private static double totalRevenue = 0.0;

    /**
     * runs the main menu loop until the user exits
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        OrderManager manager = new OrderManager();
        boolean isRunning = true;

        System.out.println("======================================");
        System.out.println("   Welcome to the Food Order System   ");
        System.out.println("======================================");

        while (isRunning) {
            System.out.println();
            System.out.println("Main Menu:");
            System.out.println("  1) Place a new order");
            System.out.println("  2) Deliver next order");
            System.out.println("  3) View pending orders");
            System.out.println("  4) Cancel an order");
            System.out.println("  5) Modify an order");
            System.out.println("  6) View price list");
            System.out.println("  7) View sales summary");
            System.out.println("  8) Exit");
            System.out.print("Enter choice (1–8): \n");

            String choice = scanner.nextLine().trim();
            if (choice.equals("1")) {
                Order newOrder = createOrder(scanner);
                manager.addOrder(newOrder);
                System.out.println();
                System.out.println("Order placed successfully! Summary:");
                System.out.println(newOrder);
            }
            else if (choice.equals("2")) {
                Order delivered = manager.deliverNextOrderFIFO();
                if (delivered != null) {
                    updateSalesCounters(delivered);
                    System.out.println();
                    System.out.println("Delivered Order:");
                    System.out.println(delivered);
                } else {
                    System.out.println();
                    System.out.println("No pending orders to deliver.");
                }
            }
            else if (choice.equals("3")) {
                System.out.println();
                System.out.println("Pending Orders:");
                manager.printPendingOrders();
            }
            else if (choice.equals("4")) {
                cancelOrder(scanner, manager);
            }
            else if (choice.equals("5")) {
                modifyOrder(scanner, manager);
            }
            else if (choice.equals("6")) {
                displayPriceList();
            }
            else if (choice.equals("7")) {
                viewSalesSummary();
            }
            else if (choice.equals("8")) {
                isRunning = false;
                System.out.println();
                System.out.println("Thank you for using the Food Order System. Goodbye!");
            }
            else {
                System.out.println();
                System.out.println("Invalid choice. Please enter a number from 1 to 8.");
            }
        }

        scanner.close();
    }

    /**
     * Prompts for a non‐blank string for the specified field name.
     *
     * parameter (scanner) is Scanner for user input
     * parameter fieldName the label to display (for example: "Customer name")
     * returns a non empty trimmed string
     */
    public static String promptNonEmpty(Scanner scanner, String fieldName) {
        while (true) {
            System.out.print(fieldName + ": ");
            String input = scanner.nextLine().trim();
            if (Validator.isNonEmpty(input)) {
                return input;
            }
            System.out.println(fieldName + " cannot be empty. Try again.");
        }
    }

    /**
     * Prompts until the user enters exactly 10 numeric digits for contact number.
     *
     * parameter (scanner) is Scanner for user input
     * returns a valid 10‐digit contact number
     */
    public static String promptValidContact(Scanner scanner) {
        while (true) {
            System.out.print("Contact number (10 digits): ");
            String input = scanner.nextLine().trim();
            if (Validator.isValidContactNumber(input)) {
                return input;
            }
            System.out.println("Must be exactly 10 numeric digits. Try again.");
        }
    }

    /**
     * Adds a FoodItem (pizza or pasta) to an existing order.
     *
     * parameter (scanner) is Scanner for user input
     * parameter (order) is the order to which the item will be added
     */
    public static void addItemToOrder(Scanner scanner, Order order) {
        while (true) {
            System.out.print("Add item – type 'pizza', 'pasta', or 'cancel': ");
            String itemType = scanner.nextLine().trim().toLowerCase();
            if (itemType.equals("pizza")) {
                List<Topping> valid = Topping.getPizzaToppings();
                List<Topping> chosen = readMultipleToppings(scanner, valid, "pizza");
                order.addItem(new Pizza(chosen));
                break;
            }
            else if (itemType.equals("pasta")) {
                List<Topping> valid = Topping.getPastaToppings();
                Pasta p = readSingleTopping(scanner, valid, "pasta");
                order.addItem(p);
                break;
            }
            else if (itemType.equals("cancel")) {
                break;
            }
            else {
                System.out.println("Invalid input. Please type 'pizza', 'pasta', or 'cancel'.");
            }
        }
    }

    /**
     * Creates a new Order by prompting for customer details and items.
     *
     * parameter (scanner) is Scanner for user input
     * returns a fully constructed Order (with at least one item)
     */
    public static Order createOrder(Scanner scanner) {
        System.out.println();
        System.out.println("--- New Order ---");
        String customerName = promptNonEmpty(scanner, "Customer name");
        String contactNumber = promptValidContact(scanner);
        String deliveryAddress = promptNonEmpty(scanner, "Delivery address");

        Order order = new Order(customerName, contactNumber, deliveryAddress);

        while (true) {
            System.out.print("\nAdd item – type 'pizza', 'pasta', or 'done': ");
            String itemType = scanner.nextLine().trim().toLowerCase();
            if (itemType.equals("pizza")) {
                List<Topping> valid = Topping.getPizzaToppings();
                List<Topping> chosen = readMultipleToppings(scanner, valid, "pizza");
                order.addItem(new Pizza(chosen));
            }
            else if (itemType.equals("pasta")) {
                List<Topping> valid = Topping.getPastaToppings();
                Pasta p = readSingleTopping(scanner, valid, "pasta");
                order.addItem(p);
            }
            else if (itemType.equals("done")) {
                if (order.getItems().isEmpty()) {
                    System.out.println("You must add at least one item.");
                } else {
                    break;
                }
            }
            else {
                System.out.println("Invalid input. Please type 'pizza', 'pasta', or 'done'.");
            }
        }
        return order;
    }

    /**
     * Displays the base price and all topping surcharges to the console.
     */
    public static void displayPriceList() {
        System.out.println();
        System.out.println("Price List");
        System.out.println("Base item price: $" + String.format("%.2f", FoodItem.getBasePrice()));

        System.out.println();
        System.out.println("Pizza Toppings:");
        for (Topping t : Topping.getPizzaToppings()) {
            System.out.println("  - " + t + ": $" + String.format("%.2f", t.getSurcharge()));
        }

        System.out.println();
        System.out.println("Pasta Toppings:");
        for (Topping t : Topping.getPastaToppings()) {
            System.out.println("  - " + t + ": $" + String.format("%.2f", t.getSurcharge()));
        }
        System.out.println();
    }

    /**
     * Cancels a pending order by prompting for its ID.
     *
     * parameter (scanner) is Scanner for user input
     * parameter (manager) is the OrderManager handling pending orders
     */
    public static void cancelOrder(Scanner scanner, OrderManager manager) {
        System.out.println();
        System.out.print("Enter Order ID to cancel: ");
        String idToCancel = scanner.nextLine().trim();
        boolean success = manager.cancelOrderByID(idToCancel);
        if (success) {
            System.out.println("Order " + idToCancel + " canceled.");
        } else {
            System.out.println("No order found with ID " + idToCancel);
        }
    }

    /**
     * Modifies an existing pending order by allowing the user to view items,
     * remove an item, or add a new item before finishing.
     *
     * parameter (scanner) Scanner for user input
     * parameter (manager) which is the OrderManager handling pending orders
     */
    public static void modifyOrder(Scanner scanner, OrderManager manager) {
        System.out.println();
        List<Order> pending = manager.listPendingOrders();
        if (pending.isEmpty()) {
            System.out.println("No pending orders to modify.");
            return;
        }

        System.out.println("Pending Orders (ID | Customer | Type | Total):");
        for (Order o : pending) {
            System.out.println(o.getOrderID() + " | " + o.getCustomerName() + " | "
                    + o.getMealType() + " | $" + String.format("%.2f", o.getTotalCost()));
        }

        System.out.print("Enter Order ID to modify: ");
        String idToModify = scanner.nextLine().trim();
        Order target = null;
        for (Order o : pending) {
            if (o.getOrderID().equals(idToModify)) {
                target = o;
                break;
            }
        }
        if (target == null) {
            System.out.println("No order found with ID " + idToModify);
            return;
        }

        boolean editing = true;
        while (editing) {
            System.out.println();
            System.out.println("Modify Order " + idToModify + ":");
            System.out.println("  1) View items");
            System.out.println("  2) Remove an item");
            System.out.println("  3) Add a new item");
            System.out.println("  4) Finish modification");
            System.out.print("Choose (1-4): ");
            String choice = scanner.nextLine().trim();
            if (choice.equals("1")) {
                System.out.println();
                System.out.println("Current items:");
                List<FoodItem> items = target.getItems();
                for (int i = 0; i < items.size(); i++) {
                    System.out.println((i + 1) + ") " + items.get(i));
                }
            }
            else if (choice.equals("2")) {
                System.out.println();
                System.out.println("Enter item number to remove:");
                List<FoodItem> items = target.getItems();
                for (int i = 0; i < items.size(); i++) {
                    System.out.println((i + 1) + ") " + items.get(i));
                }
                System.out.print("Number to remove (1-" + items.size() + "): ");
                try {
                    int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
                    target.removeItem(idx);
                    System.out.println("Item removed.");
                }
                catch (Exception e) {
                    System.out.println("Invalid index. No item removed.");
                }
            }
            else if (choice.equals("3")) {
                System.out.println();
                System.out.println("Add a new item:");
                addItemToOrder(scanner, target);
                System.out.println("Item added.");
            }
            else if (choice.equals("4")) {
                editing = false;
            }
            else {
                System.out.println("Invalid choice. Please enter 1–4.");
            }
        }

        System.out.println("Modification complete. Updated order:");
        System.out.println(target);
    }

    /**
     * Reads up to 6 pizza toppings from the user. Typing "done" finishes early.
     *
     * parameter (scanner) is Scanner for user input
     * parameter valid list of valid pizza toppings
     * parameter itemType the string "pizza" (used in prompts)
     * returns the list of chosen pizza toppings which can be empty if plain pizza
     */
    public static List<Topping> readMultipleToppings(Scanner scanner,
                                                     List<Topping> valid, String itemType) {
        List<Topping> chosen = new ArrayList<>();
        System.out.println("Available " + itemType + " toppings: " + valid);
        while (chosen.size() < 6) {
            System.out.print("Enter topping name or 'done': ");
            String input = scanner.nextLine().trim().toUpperCase();
            if (input.equals("DONE")) {
                break;
            }
            try {
                Topping t = Topping.valueOf(input);
                if (!valid.contains(t)) {
                    System.out.println(t + " is not valid for " + itemType + ".");
                } else {
                    chosen.add(t);
                    System.out.println(t + " added.");
                }
            }
            catch (IllegalArgumentException e) {
                System.out.println("Unknown topping. Try again or type 'done'.");
            }
        }
        return chosen;
    }

    /**
     * Reads exactly one pasta topping from the user, or returns a plain Pasta if "done" is typed.
     *
     * parameter (scanner) is  Scanner for user input
     * parameter (valid) is  list of valid pasta toppings
     * parameter (itemType) is the string "pasta"
     * returns a new Pasta object (with topping or plain)
     */
    public static Pasta readSingleTopping(Scanner scanner,
                                          List<Topping> valid, String itemType) {
        System.out.println("Available " + itemType + " toppings: " + valid);
        System.out.println("(Or type 'done' for plain pasta)");
        while (true) {
            System.out.print("Enter topping name or 'done': ");
            String input = scanner.nextLine().trim().toUpperCase();
            if (input.equals("DONE")) {
                return new Pasta();
            }
            try {
                Topping t = Topping.valueOf(input);
                if (valid.contains(t)) {
                    System.out.println(t + " added.");
                    return new Pasta(t);
                } else {
                    System.out.println(t + " is not valid for " + itemType + ".");
                }
            }
            catch (IllegalArgumentException e) {
                System.out.println("Unknown topping. Try again or type 'done'.");
            }
        }
    }

    /**
     * Increments the sales counters based on the delivered order’s meal type
     * and adds its total cost to the revenue.
     *
     * parameter order the delivered Order
     */
    public static void updateSalesCounters(Order order) {
        MealType type = order.getMealType();
        if (type == MealType.MEAT) {
            meatCount++;
        }
        else if (type == MealType.VEGETARIAN) {
            vegetarianCount++;
        }
        else {
            veganCount++;
        }
        totalRevenue += order.getTotalCost();
    }

    /**
     * Displays the summary of delivered orders and total revenue.
     */
    public static void viewSalesSummary() {
        int totalDelivered = meatCount + vegetarianCount + veganCount;
        System.out.println();
        System.out.println("Sales Summary:");
        System.out.println("  Total orders delivered: " + totalDelivered);
        System.out.println("  Meat orders: " + meatCount);
        System.out.println("  Vegetarian orders: " + vegetarianCount);
        System.out.println("  Vegan orders: " + veganCount);
        System.out.println("  Total revenue: $" + String.format("%.2f", totalRevenue));
    }
}
