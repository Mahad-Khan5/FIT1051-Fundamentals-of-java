import java.util.List;

/**
 * Enum representing the classification of an order based on its toppings.
 *
 * MEAT: if any item has a meat-based topping (HAM, SEAFOOD, BOLOGNESE, MARINARA)
 * VEGETARIAN: if no meat but at least one vegetarian-type topping
 * (CHEESE, MUSHROOMS, TOMATO, PINEAPPLE, PRIMAVERA)
 *
 * VEGAN if there is no MEAT and no VEGETARIAN toppings
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public enum MealType {

    MEAT,
    VEGETARIAN,
    VEGAN;

    /**
     * Determines the meal type for a list of food items.
     *
     * parameter (items) the list of FoodItem objects in an order which is not null
     * returns the MealType
     * throws IllegalArgumentException if items is null
     */
    public static MealType fromItems(List<FoodItem> items) {
        if (items == null) {
            throw new IllegalArgumentException("Item list cannot be null");
        }

        boolean sawVegetarianToppingOnly = false;

        for (FoodItem item : items) {
            for (Topping topping : item.getToppings()) {
                // If any topping is a meat‐based topping, return MEAT
                if (topping == Topping.HAM
                        || topping == Topping.SEAFOOD
                        || topping == Topping.BOLOGNESE
                        || topping == Topping.MARINARA) {
                    return MEAT;
                }
                // If any topping is a vegetarian‐only topping, note it
                if (topping == Topping.CHEESE
                        || topping == Topping.MUSHROOMS
                        || topping == Topping.TOMATO
                        || topping == Topping.PINEAPPLE
                        || topping == Topping.PRIMAVERA) {
                    sawVegetarianToppingOnly = true;
                }
            }
        }

        // If no meat but saw a vegetarian‐type topping, return VEGETARIAN
        if (sawVegetarianToppingOnly) {
            return VEGETARIAN;
        }

        // Otherwise, no meat and no vegetarian toppings implies VEGAN
        return VEGAN;
    }
}
