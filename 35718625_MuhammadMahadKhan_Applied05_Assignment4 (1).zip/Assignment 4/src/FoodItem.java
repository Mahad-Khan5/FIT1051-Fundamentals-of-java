import java.util.List;

/**
 * Represents an abstract base class for all food items.
 * Stores name and base price.
 *
 * Subclasses:
 * calculatePrice() - returns final price with any extras.
 * getToppings() - returns a list of item toppings.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */
public abstract class FoodItem {

    /**
     * The name of this food item.
     */
    private String name;

    /**
     * The fixed base price for every food item.
     */
    private static final double BASE_PRICE = 11.50;

    /**
     * Constructs a new FoodItem with the specified name.
     *
     * parameter (name) is the name of the food item which must not be null or blank
     * throws IllegalArgumentException if name is null or blank
     */
    public FoodItem(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be null or blank");
        }
        this.name = name;
    }

    /**
     * returns the name of the Food item
     */
    public String getName() {
        return name;
    }

    /**
     * returns the fixed base price for all food items
     */
    public static double getBasePrice() {
        return BASE_PRICE;
    }

    /**
     * Calculates the total price of this food item, including any surcharges
     * for toppings or other additions.
     *
     * returns the total calculated price for the Food item
     */
    public abstract double calculatePrice();

    /**
     * Returns a list of toppings applied to this Food item
     *
     * returns a list of toppings for this Food item
     */
    public abstract List<Topping> getToppings();

    /**
     * Returns a string representation of the Food item, showing the name of the Food item,
     * toppings, and total price in a formatted way
     *
     * returns a formatted description of the food item
     */
    @Override
    public String toString() {
        List<Topping> toppings = getToppings();
        StringBuilder sb = new StringBuilder();
        sb.append(name).append(" [");
        for (int i = 0; i < toppings.size(); i++) {
            sb.append(toppings.get(i));
            if (i < toppings.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append("] - Price: ").append(String.format("%.2f", calculatePrice()));
        return sb.toString();
    }
}
