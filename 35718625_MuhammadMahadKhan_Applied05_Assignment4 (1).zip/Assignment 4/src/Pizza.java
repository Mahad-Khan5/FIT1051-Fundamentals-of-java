import java.util.List;
import java.util.ArrayList;

/**
 * Represents a pizza item with zero to six pizza type toppings.
 *
 * Extends FoodItem to include topping surcharges in price calculation.
 *
 * A pizza with no toppings is considered vegan and costs only the base price.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class Pizza extends FoodItem {

    /**
     * Maximum number of toppings allowed on a single pizza are 6
     */
    private static final int MAX_TOPPINGS = 6;

    /**
     * The list of toppings applied to this pizza
     */
    private List<Topping> toppings;

    /**
     * Constructs a new Pizza with the inputted list of toppings.
     *
     * Validates that the topping list is not null, does not exceed MAX_TOPPINGS,
     * and that each topping is valid for pizza.
     *
     * parameter (toppings) is the list of pizza-type toppings (0 to MAX_TOPPINGS)
     * throws IllegalArgumentException if toppings is null, has more than MAX_TOPPINGS,
     * or contains any topping not valid for pizza
     */

    public Pizza(List<Topping> toppings) {
        super("Pizza");
        if (toppings == null) {
            throw new IllegalArgumentException("Toppings list cannot be null");
        }
        if (toppings.size() > MAX_TOPPINGS) {
            throw new IllegalArgumentException(
                    "A pizza can have at most " + MAX_TOPPINGS + " toppings"
            );
        }
        for (Topping t : toppings) {
            if (!t.isPizzaTopping()) {
                throw new IllegalArgumentException(
                        t + " is not a valid pizza topping"
                );
            }
        }
        this.toppings = new ArrayList<>();
        for (Topping t : toppings) {
            this.toppings.add(t);
        }
    }

    /**
     * Calculates the total price of this pizza as the base price plus
     * each topping’s surcharge. If no toppings are applied, returns
     * the base price alone.
     *
     * returns the total pizza price
     */
    @Override
    public double calculatePrice() {
        double total = getBasePrice();
        for (Topping t : toppings) {
            total += t.getSurcharge();
        }
        return total;
    }

    /**
     * Returns a copy of the list of toppings on this pizza.
     *
     * The returned list will be empty if no toppings were selected.
     *
     * returns a new ArrayList containing this pizza’s toppings
     */

    @Override
    public List<Topping> getToppings() {
        List<Topping> copy = new ArrayList<>();
        for (Topping t : toppings) {
            copy.add(t);
        }
        return copy;
    }
}
