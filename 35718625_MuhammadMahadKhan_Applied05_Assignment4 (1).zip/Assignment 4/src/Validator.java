import java.util.List;

/**
 * Utility class for input validation across the application.
 *
 * Contains static methods to validate customer names, contact numbers,
 * delivery addresses, and topping selections.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class Validator {

    /**
     * parameter input the string to check
     * returns true if input is non-null and contains at least one non-whitespace character
     */

    public static boolean isNonEmpty(String input) {
        return input != null && !input.trim().isEmpty();
    }

    /**
     * parameter input the contact number string to check
     * returns true if input is exactly length 10 and all characters are digits
     */

    public static boolean isValidContactNumber(String input) {
        if (input == null || input.length() != 10) {
            return false;
        }
        for (int i = 0; i < 10; i++) {
            if (!Character.isDigit(input.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * parameter (input) is the delivery address string to check
     * returns true if input is non-null and not blank after trimming
     */

    public static boolean isValidAddress(String input) {
        return isNonEmpty(input);
    }

    /**
     * parameter toppings the list of toppings to validate which may be empty
     * parameter valid the list of toppings allowed for this item (pizza or pasta)
     * parameter maxCount the maximum number of toppings permitted
     * returns true if toppings is non-null, size is less than or equal to maxCount,
     *         and every topping exists in the valid list
     */

    public static boolean areToppingsValid(
            List<Topping> toppings, List<Topping> valid, int maxCount) {
        if (toppings == null || toppings.size() > maxCount) {
            return false;
        }
        for (Topping t : toppings) {
            if (!valid.contains(t)) {
                return false;
            }
        }
        return true;
    }
}
