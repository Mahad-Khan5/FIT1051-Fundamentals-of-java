import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;

/**
 * Represents a customer order, containing personal details and a list of FoodItem objects
 *
 * Calculates the meal type and total cost dynamically as items are added
 * Each order receives a "LastNameXX" style ID (e.g. "Khan01", "Walker02") and a timestamp
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class Order {

    /**
     * Static counter to assign unique two digit suffixes to order IDs
     */
    private static int nextCounter = 1;

    /**
     * The unique order ID which gives (last name + two digit counter)
     */
    private final String orderID;

    /**
     * The timestamp when this order was created
     */
    private final LocalDateTime timestamp;

    /**
     * The customer's name
     */
    private final String customerName;

    /**
     * The customer's contact number
     */
    private final String contactNumber;

    /**
     * The delivery address
     */
    private final String deliveryAddress;

    /**
     * The list of items added to this order
     */
    private final List<FoodItem> items;

    /**
     * The meal type (MEAT, VEGETARIAN, or VEGAN) based on toppings
     */
    private MealType mealType;

    /**
     * The calculated total cost of all items in this order
     */
    private double totalCost;

    /**
     * Constructs a new Order with the specified customer details.
     * Generates an order ID based on the last name plus a two‐digit counter,
     * sets the timestamp to now, and initializes mealType and totalCost to defaults.
     *
     * parameter customerName is the name of the customer (non‐null, non‐blank)
     * parameter contactNumber is the customer's contact number (non‐null, non‐blank)
     * parameter deliveryAddress is the delivery address (non‐null, non‐blank)
     * throws IllegalArgumentException if any parameter is null or blank
     */
    public Order(String customerName, String contactNumber, String deliveryAddress) {
        if (customerName == null || customerName.isBlank()
                || contactNumber == null || contactNumber.isBlank()
                || deliveryAddress == null || deliveryAddress.isBlank()) {
            throw new IllegalArgumentException("All customer fields are required");
        }

        this.customerName = customerName.trim();
        this.contactNumber = contactNumber.trim();
        this.deliveryAddress = deliveryAddress.trim();

        String[] nameParts = this.customerName.split(" ");
        String lastName = nameParts[nameParts.length - 1];
        String suffix = String.format("%02d", nextCounter++);
        this.orderID = lastName + suffix;

        this.timestamp = LocalDateTime.now();
        this.items = new ArrayList<>();
        this.mealType = MealType.VEGAN; // default before any items are added
        this.totalCost = 0.0;
    }

    /**
     * Adds a FoodItem to this order, then updates the meal type and total cost
     *
     * parameter (item) is the FoodItem to add which is not null
     * throws IllegalArgumentException if item is null
     */
    public void addItem(FoodItem item) {
        if (item == null) {
            throw new IllegalArgumentException("Item cannot be null");
        }
        items.add(item);
        recomputeMealType();
        recomputeTotalCost();
    }

    /**
     * Removes the FoodItem at the specified index, then updates meal type and total cost.
     *
     * parameter (index) is the index of the item to remove (0 based)
     * throws IndexOutOfBoundsException if index is out of range
     */
    public void removeItem(int index) {
        if (index < 0 || index >= items.size()) {
            throw new IndexOutOfBoundsException("Invalid item index");
        }
        items.remove(index);
        recomputeMealType();
        recomputeTotalCost();
    }

    /**
     * Returns the customer's contact number
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * Returns the customer's name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * returns the meal type (MEAT, VEGETARIAN, or VEGAN)
     */
    public MealType getMealType() {
        return mealType;
    }

    /**
     * returns the total calculated cost
     */
    public double getTotalCost() {
        return totalCost;
    }

    /**
     * returns a new ArrayList containing all FoodItem objects
     */
    public List<FoodItem> getItems() {
        return new ArrayList<>(items);
    }

    /**
     * returns the delivery address
     */
    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    /**
     * returns the unique order ID string
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * returns the timestamp when this order was created.
     */
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    /**
     * Recomputes the meal type based on current items and their toppings.
     * Sets mealType to MEAT if any meat topping is found,
     * otherwise VEGETARIAN if any vegetariant ype topping is found,
     * otherwise VEGAN.
     */
    private void recomputeMealType() {
        boolean sawVegetarian = false;
        for (FoodItem fi : items) {
            for (Topping t : fi.getToppings()) {
                if (t == Topping.HAM
                        || t == Topping.SEAFOOD
                        || t == Topping.BOLOGNESE
                        || t == Topping.MARINARA) {
                    mealType = MealType.MEAT;
                    return;
                }
                if (t == Topping.CHEESE
                        || t == Topping.MUSHROOMS
                        || t == Topping.TOMATO
                        || t == Topping.PINEAPPLE
                        || t == Topping.PRIMAVERA) {
                    sawVegetarian = true;
                }
            }
        }
        mealType = sawVegetarian ? MealType.VEGETARIAN : MealType.VEGAN;
    }

    /**
     * Recomputes the total cost by summing the prices of all items.
     */
    private void recomputeTotalCost() {
        double sum = 0.0;
        for (FoodItem fi : items) {
            sum += fi.calculatePrice();
        }
        totalCost = sum;
    }

    /**
     * Returns a formatted string summarizing the order,
     * including order ID, timestamp, customer details, each item,
     * meal type, and total cost.
     *
     * returns the formatted order description
     */
    @Override
    public String toString() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();
        sb.append("Order ID: ")
                .append(orderID)
                .append(" | Ordered at: ")
                .append(timestamp.format(dtf))
                .append("\n")
                .append("Order for ")
                .append(customerName)
                .append(" (")
                .append(contactNumber)
                .append(")\n")
                .append("Address: ")
                .append(deliveryAddress)
                .append("\n")
                .append("Items:\n");
        for (FoodItem fi : items) {
            sb.append("  - ").append(fi).append("\n");
        }
        sb.append("Meal Type: ")
                .append(mealType)
                .append(" | Total: $")
                .append(String.format("%.2f", totalCost));
        return sb.toString();
    }
}
