import java.util.List;
import java.util.ArrayList;

/**
 * Represents a pasta item with either one pasta type topping or zero toppings/plain pasta
 *
 * Extends FoodItem to include topping surcharge in price calculation.
 *
 * A plain pasta (no toppings) is considered vegan and costs only the base price.
 *
 * @author Muhammad Mahad Khan
 * @version 1.0
 */

public class Pasta extends FoodItem {

    /**
     * The single topping applied to this pasta, or null if pasta is plain.
     */
    private Topping topping;

    /**
     * Constructs a new Pasta with exactly one topping.
     *
     * parameter (topping) the pasta type topping to apply which is not null
     * throws IllegalArgumentException if topping is null or not valid for pasta
     */
    public Pasta(Topping topping) {
        super("Pasta");
        if (topping == null || !topping.isPastaTopping()) {
            throw new IllegalArgumentException(
                    "One valid pasta topping required, or use no‐arg constructor for plain pasta"
            );
        }
        this.topping = topping;
    }

    /**
     * Constructs a new plain (zero‐topping) vegan pasta.
     */
    public Pasta() {
        super("Pasta");
        this.topping = null;
    }

    /**
     * Calculates the price of this pasta as the base price plus
     * the topping's surcharge if a topping is present.
     *
     * returns the total price of this pasta
     */
    @Override
    public double calculatePrice() {
        if (topping == null) {
            return getBasePrice();
        }
        return getBasePrice() + topping.getSurcharge();
    }

    /**
     * Returns a list containing the single topping for this pasta,
     * or an empty list if no topping was chosen.
     *
     * returns an ArrayList with the pasta topping, or empty if plain
     */

    @Override
    public List<Topping> getToppings() {
        List<Topping> list = new ArrayList<>();
        if (topping != null) {
            list.add(topping);
        }
        return list;
    }
}
