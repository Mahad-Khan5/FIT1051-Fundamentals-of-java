import java.util.Scanner;

public class Assessment1
{

    public static void main(String[] args)
    {
        Assessment1 assessment1 = new Assessment1();

        assessment1.task2();
        assessment1.task3();
    }

    private void task2()
    {
        System.out.println("TASK 2");

        // Instantiate a WeatherData object, day1, using the default constructor
        WeatherData day1 = new WeatherData();

        // Instantiates a WeatherData object, day2, for 17th February 2025, with a minimum
        // temperature of 14, a maximum of 21, 2mm rainfall and description of “sunny”
        WeatherData day2 = new WeatherData(20250217, 14.0, 21.0, 2, "sunny");

        // Use the toString method to display each day
        System.out.println(day1.toString());
        System.out.println(day2.toString());
    }

    private void task3()
    {
        System.out.println("TASK 3");

        //Part A
        double [] temperatures = new double[7];

        // Part B and C
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < temperatures.length; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.print("Enter temperature " + (i + 1) + " (between 0 and 50): ");
                double temp = scanner.nextDouble();
                if (temp >= 0 && temp <= 50) {
                    temperatures[i] = temp;
                    validInput = true;
                } else {
                    System.out.println("Invalid temperature. Please enter a value between 0 and 50.");
                }
            }
        }

        //Part D
        double minTemperature = temperatures[0];
        double maxTemperature = temperatures[0];

        for (double temp : temperatures) {
            if (temp < minTemperature) {
                minTemperature = temp;
            }
            if (temp > maxTemperature) {
                maxTemperature = temp;
            }
        }

        System.out.println("Minimum temperature: " + minTemperature);
        System.out.println("Maximum temperature: " + maxTemperature);
    }

}
