
/**
A class to store a date, minimum temperature, maximum temperature, the amount of rainfall amount,
description of the day
@author Muhammad Mahad Khan
@version 1.0
 */
public class WeatherData
{
    private int date; // Date in YYYYMMDD format
    private double minimumTemperature; // Minimum temperature for the day
    private double maximumTemperature; // Maximum temperature for the day
    private int rainfallAmount; // Rainfall in mm
    private String description; // Description of the day e.g, "sunny"

    //Default constructor
    public WeatherData() {
        this.date = 0;
        this.minimumTemperature = 0.0;
        this.maximumTemperature = 0.0;
        this.rainfallAmount = 0;
        this.description = "";
    }

    //Non-default constructor
    public WeatherData(int date, double minTemp, double maxTemp, int rainfall, String description) {
        this.date = date;
        this.minimumTemperature = minTemp;
        this.maximumTemperature = maxTemp;
        this.rainfallAmount = rainfall;
        this.description = description;
    }

    //Getters
    public int getDate() {
        return date;
    }

    public double getMinimumTemperature() {
        return minimumTemperature;
    }

    public double getMaximumTemperature() {
        return maximumTemperature;
    }

    public int getRainfallAmount() {
        return rainfallAmount;
    }

    public String getDescription() {
        return description;
    }


    //setters
    public void setDate(int date) {
        this.date = date;
    }

    public void setMinimumTemperature(double minTemp) {
        this.minimumTemperature = minTemp;
    }

    public void setMaximumTemperature(double maxTemp) {
        this.maximumTemperature = maxTemp;
    }

    public void setRainfallAmount(int rainfall) {
        this.rainfallAmount = rainfall;
    }

    public void setDescription(String desc) {
        this.description = desc;
    }

    //toString method
    public String toString() {
        return "Weather of the day (" + "Date=" + date +
                ", Minimum Temperature = " + minimumTemperature +
                ", Maximum Temperature = " + maximumTemperature +
                ", Rainfall Amount = " + rainfallAmount +
                ", Type of weather = '" + description + "')";
    }
}
